--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Thai_Thailand.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: carrent; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA carrent;


ALTER SCHEMA carrent OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: carrent_users; Type: TABLE; Schema: carrent; Owner: postgres
--

CREATE TABLE carrent.carrent_users (
    user_id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    phone character varying(10) NOT NULL,
    users_role character varying(20) DEFAULT 'customer'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE carrent.carrent_users OWNER TO postgres;

--
-- Name: carrent_users_user_id_seq; Type: SEQUENCE; Schema: carrent; Owner: postgres
--

ALTER TABLE carrent.carrent_users ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME carrent.carrent_users_user_id_seq
    START WITH 10000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cars; Type: TABLE; Schema: carrent; Owner: postgres
--

CREATE TABLE carrent.cars (
    cars_id integer NOT NULL,
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    license_plate character varying(20) NOT NULL,
    year integer,
    price_per_day numeric(10,2),
    price_per_week numeric(10,2),
    status character varying(20) DEFAULT 'available'::character varying,
    image_url text
);


ALTER TABLE carrent.cars OWNER TO postgres;

--
-- Name: cars_cars_id_seq; Type: SEQUENCE; Schema: carrent; Owner: postgres
--

CREATE SEQUENCE carrent.cars_cars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE carrent.cars_cars_id_seq OWNER TO postgres;

--
-- Name: cars_cars_id_seq; Type: SEQUENCE OWNED BY; Schema: carrent; Owner: postgres
--

ALTER SEQUENCE carrent.cars_cars_id_seq OWNED BY carrent.cars.cars_id;


--
-- Name: rentals; Type: TABLE; Schema: carrent; Owner: postgres
--

CREATE TABLE carrent.rentals (
    rentals_id integer NOT NULL,
    user_id integer NOT NULL,
    cars_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    total_price numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'completed'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    rental_type character varying(20),
    CONSTRAINT rentals_check CHECK ((end_date > start_date)),
    CONSTRAINT rentals_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'confirmed'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE carrent.rentals OWNER TO postgres;

--
-- Name: rentals_rentals_id_seq; Type: SEQUENCE; Schema: carrent; Owner: postgres
--

CREATE SEQUENCE carrent.rentals_rentals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE carrent.rentals_rentals_id_seq OWNER TO postgres;

--
-- Name: rentals_rentals_id_seq; Type: SEQUENCE OWNED BY; Schema: carrent; Owner: postgres
--

ALTER SEQUENCE carrent.rentals_rentals_id_seq OWNED BY carrent.rentals.rentals_id;


--
-- Name: cars cars_id; Type: DEFAULT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.cars ALTER COLUMN cars_id SET DEFAULT nextval('carrent.cars_cars_id_seq'::regclass);


--
-- Name: rentals rentals_id; Type: DEFAULT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.rentals ALTER COLUMN rentals_id SET DEFAULT nextval('carrent.rentals_rentals_id_seq'::regclass);


--
-- Data for Name: carrent_users; Type: TABLE DATA; Schema: carrent; Owner: postgres
--

COPY carrent.carrent_users (user_id, username, password, full_name, email, phone, users_role, is_active, created_at, updated_at) FROM stdin;
\.
COPY carrent.carrent_users (user_id, username, password, full_name, email, phone, users_role, is_active, created_at, updated_at) FROM '$$PATH$$/4926.dat';

--
-- Data for Name: cars; Type: TABLE DATA; Schema: carrent; Owner: postgres
--

COPY carrent.cars (cars_id, brand, model, license_plate, year, price_per_day, price_per_week, status, image_url) FROM stdin;
\.
COPY carrent.cars (cars_id, brand, model, license_plate, year, price_per_day, price_per_week, status, image_url) FROM '$$PATH$$/4928.dat';

--
-- Data for Name: rentals; Type: TABLE DATA; Schema: carrent; Owner: postgres
--

COPY carrent.rentals (rentals_id, user_id, cars_id, start_date, end_date, total_price, status, created_at, rental_type) FROM stdin;
\.
COPY carrent.rentals (rentals_id, user_id, cars_id, start_date, end_date, total_price, status, created_at, rental_type) FROM '$$PATH$$/4930.dat';

--
-- Name: carrent_users_user_id_seq; Type: SEQUENCE SET; Schema: carrent; Owner: postgres
--

SELECT pg_catalog.setval('carrent.carrent_users_user_id_seq', 10000, true);


--
-- Name: cars_cars_id_seq; Type: SEQUENCE SET; Schema: carrent; Owner: postgres
--

SELECT pg_catalog.setval('carrent.cars_cars_id_seq', 16, true);


--
-- Name: rentals_rentals_id_seq; Type: SEQUENCE SET; Schema: carrent; Owner: postgres
--

SELECT pg_catalog.setval('carrent.rentals_rentals_id_seq', 2, true);


--
-- Name: carrent_users carrent_users_email_key; Type: CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.carrent_users
    ADD CONSTRAINT carrent_users_email_key UNIQUE (email);


--
-- Name: carrent_users carrent_users_pkey; Type: CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.carrent_users
    ADD CONSTRAINT carrent_users_pkey PRIMARY KEY (user_id);


--
-- Name: carrent_users carrent_users_username_key; Type: CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.carrent_users
    ADD CONSTRAINT carrent_users_username_key UNIQUE (username);


--
-- Name: cars cars_license_plate_key; Type: CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.cars
    ADD CONSTRAINT cars_license_plate_key UNIQUE (license_plate);


--
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (cars_id);


--
-- Name: rentals rentals_pkey; Type: CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.rentals
    ADD CONSTRAINT rentals_pkey PRIMARY KEY (rentals_id);


--
-- Name: rentals rentals_user_id_cars_id_start_date_end_date_key; Type: CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.rentals
    ADD CONSTRAINT rentals_user_id_cars_id_start_date_end_date_key UNIQUE (user_id, cars_id, start_date, end_date);


--
-- Name: rentals rentals_cars_id_fkey; Type: FK CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.rentals
    ADD CONSTRAINT rentals_cars_id_fkey FOREIGN KEY (cars_id) REFERENCES carrent.cars(cars_id);


--
-- Name: rentals rentals_user_id_fkey; Type: FK CONSTRAINT; Schema: carrent; Owner: postgres
--

ALTER TABLE ONLY carrent.rentals
    ADD CONSTRAINT rentals_user_id_fkey FOREIGN KEY (user_id) REFERENCES carrent.carrent_users(user_id);


--
-- PostgreSQL database dump complete
--

